SMODS.Rarity {
    key = "foolish",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('5d6e55'),
    loc_txt = {
        name = "Foolish"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "power",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.1,
    badge_colour = HEX('ff9f2c'),
    loc_txt = {
        name = "Power"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "weird",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.1,
    badge_colour = HEX('ffffff'),
    loc_txt = {
        name = "????????"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}