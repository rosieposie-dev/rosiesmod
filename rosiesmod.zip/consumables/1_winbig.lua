SMODS.Consumable {
    key = '1_winbig',
    set = 'gambling',
    pos = { x = 1, y = 1 },
    config = { extra = {
        odds = 3,
        double_limit = 9999
    } },
    loc_txt = {
        name = 'WIN BIG',
        text = {
        [1] = '{C:green}DOUBLE MONEY{} or {C:attention}NOTHING{}'
    }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_f6e9d294', 1, card.ability.extra.odds, 'c_rosie_1_winbig', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    local double_amount = math.min(G.GAME.dollars, 9999)
                    ease_dollars(double_amount, true)
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}